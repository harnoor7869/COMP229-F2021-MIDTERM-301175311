// Harnoor Kaur(301175311)--------COMP229
module.exports = {
  //local MongoDB deployment ->
  "URI": "mongodb+srv://Dbuser:Hkaur773@@mongo-server.ccjob.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
};
